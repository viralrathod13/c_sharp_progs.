﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace bills
{
    public partial class Form3 : Form
    {
        SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\viral\bills\bills\custbill.mdf;Integrated Security=True;User Instance=True");
        public Form3()
        {
            InitializeComponent();
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            string sql = "select * from client";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "metno";

        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
                Form1 f1 = new Form1();
                f1.Show();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "insert into bill values('" + comboBox1.Text + "','" + textBox1.Text + "','" + textBox3.Text + "','" + comboBox2.Text + "','" + textBox4.Text + "')";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            MessageBox.Show("Bill Saved successfully");


        }

        private void clear()
        {
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            textBox1.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox1.Focus();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "select*from bill where mtno='" + comboBox1.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    textBox1.Text = dt.Rows[i][2].ToString();
                    // button1.Enabled = false;
                }
            }
            else
            {
                textBox1.Text = "0";
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "select*from bill where meter_no='" + comboBox1.Text + "'and month='" + comboBox2.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Already exits ! ", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                clear();
            }
            else
            {
                int previous_units = Convert.ToInt32(textBox1.Text);
                int current_units = Convert.ToInt32(textBox3.Text);
                int units = current_units - previous_units;
                int amount = units * 10;
                textBox3.Text = amount.ToString();

                
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            clear();
        }

     

      
       

      
    }
}
