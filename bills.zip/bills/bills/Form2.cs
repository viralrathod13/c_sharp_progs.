﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace bills
{
    public partial class Form2 : Form
    {
        
        SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\viral\bills\bills\custbill.mdf;Integrated Security=True;User Instance=True");
        public Form2()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
                Form1 f1 = new Form1();
                f1.Show();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select * from client where meter_no = '" + textBox2.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Duplicate Record ! ");
            }
            else
            {
                if (textBox1.Text != "" && textBox2.Text != "")
                {
                    string sql1 = "insert into client values('" + textBox1.Text + "','" + textBox2.Text + "')";
                    SqlDataAdapter da1 = new SqlDataAdapter(sql, cn);
                    DataTable dt1 = new DataTable();
                    da1.Fill(dt1);

                    MessageBox.Show("Record inserted");
                    clear();
                }
                else
                {
                    MessageBox.Show("Please Enter Values Properly");
                }

            }
        }

        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox1.Focus();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        

       

       

       
    }

       
}
