﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace fibonacci_series
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, i, a = 0, b = 1, c;
            Console.Write("input no : ");
            n = Convert.ToInt32(Console.ReadLine());
            for (i = a; i <= n; i++)
            {
                Console.Write(a + "");
                c = a + b;
                a = b;
                b = c;
            }

            Console.WriteLine("while loop :");
            a = 0; b = 1; i = a;
            while (i <= n)
            {
                Console.Write(a + "");
                c = a + b;
                a = b;
                b = c;
                i++;
            }

            Console.WriteLine("do...while loop:");
            a = 0; b = 1; i = a;
            do
            {
                Console.Write(a + "");
                c = a + b;
                a = b;
                b = c;
                i++;
            }
            while (i <= 5);
              Console.Read();
        }
    }
}
