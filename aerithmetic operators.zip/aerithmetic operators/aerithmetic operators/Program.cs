﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace aerithmetic_operators
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            Console.WriteLine("input value of a & b ");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());

            c = a + b;
            Console.WriteLine("add. is " + c);

            c = a - b;
            Console.WriteLine("sub. is " + c);

            c = a * b;
            Console.WriteLine("mul. is " + c);

            c = a / b;
            Console.WriteLine("div. is " + c);

            c = a % b;
            Console.WriteLine("mod. is " + c);

            Console.Read();
        }
    }
}
