﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace marksheet
{
    class Program
    {
        static void Main(string[] args)
        {
            int s1, s2, s3, total;
            float per;
            Console.Write("Enter marks");
            s1 = Convert.ToInt32(Console.ReadLine());
            s2 = Convert.ToInt32(Console.ReadLine());
            s3 = Convert.ToInt32(Console.ReadLine());
            total = s1 + s2 + s3;
            per = total / 3;
            Console.WriteLine("Your percentage is" + per);

            if (per >= 80)
            {
                Console.WriteLine("A");
            }
            else if (per <= 80 && per>=60)
            {
                Console.WriteLine("b");
            }
            else if (per <= 60 && per >= 40)
            {
                Console.WriteLine("fail");
            }

            Console.Read();

        }
    }
}
