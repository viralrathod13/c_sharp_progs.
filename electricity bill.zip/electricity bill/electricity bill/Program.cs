﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace electricity_bill
{
    class Program
    {
        static void Main(string[] args)
        {
            int curunit, u1, u2, u3;
            float totlau;

            Console.Write("enter units : ");
            curunit = Convert.ToInt32(Console.Read());

            switch (curunit <= 100)
            {
                case 1:
                    u1 = curunit * 5;
                    Console.Write("your amount is : " + u1);
                    break;

                default:
                    Console.Write("Enter unit ")
            }

             switch (curunit <= 200)
            {
                case 1:
                    u2 = curunit * 6;
                    Console.Write("your amount is : " + u2);
                    break;

                default:
                    Console.Write("Enter unit ")
            }

             switch (curunit <= 300)
            {
                case 1:
                    u3 = curunit * 7;
                    Console.Write("your amount is : " + u3);
                    break;

                default:
                    Console.Write("Enter unit ")
            }

            Console.Read();
        }
    }
}
