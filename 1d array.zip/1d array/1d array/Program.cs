﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1d_array
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] cars = { "HVK30", "KILO141", "TYPE25", "STRIKER" };
            foreach (string val in cars)
            {
                Console.WriteLine(val);
            }



        }
    }
}
