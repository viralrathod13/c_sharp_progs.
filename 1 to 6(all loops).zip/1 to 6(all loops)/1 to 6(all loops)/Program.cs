﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_to_6_all_loops_
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            //----------//
            Console.WriteLine("for loop :");//for loop
            for (i = 1; i <= 5; i++)
            {
                Console.Write(i + "");
            }
            //-----------//

            Console.WriteLine("while loop :");//while loop
            while (i <= 5)
            {
                Console.Write(i + "");
                i++;
            }

            //------------//

            Console.WriteLine("do,,while loop :");//do..while loop

            i = 1;
            do
            {
                Console.Write(i + "");
                i++;
            }
            while (i <= 5);
            Console.Read();
        }
    }
}
