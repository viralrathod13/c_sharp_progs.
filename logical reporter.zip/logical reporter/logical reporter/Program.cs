﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace logical_reporter
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            Console.WriteLine("Enter value of a,b,c");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            c = Convert.ToInt32(Console.ReadLine());

            if (a == b && b == c)
            {
                Console.WriteLine("a=b=c");
                   
            }
            Console.Read();
        }
    }
}
