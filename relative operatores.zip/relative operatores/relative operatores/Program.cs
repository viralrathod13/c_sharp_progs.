﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace relative_operatores
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            Console.WriteLine("Enter values of a & b");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());

            if (a == b)
                Console.WriteLine("a==b");
            if (a > b)
                Console.WriteLine("a>b");
            if (a < b)
                Console.WriteLine("a<b");
            if (a != b)
                Console.WriteLine("a!=b");
            if (a >= b)
                Console.WriteLine("a>=b");
            if (a <= b)
                Console.WriteLine("a<=b");

            Console.Read();
        }
    }
}
