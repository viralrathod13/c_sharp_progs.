﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace stud_info_1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            clear();
        }

        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            label7.Text = "";
            label8.Text = "";
            label9.Text = "";
            textBox1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(textBox3.Text);
            int y = Convert.ToInt32(textBox4.Text);
            int z = Convert.ToInt32(textBox5.Text);
            int h = Convert.ToInt32(textBox6.Text);
            int tot = x + y + z + h;

            label7.Text = tot.ToString();

            int per = tot / 4;
            label8.Text = per.ToString();

            if (per < 100 && per >= 70)
                label9.Text = "A";
            else if (per < 70 && per >= 60)
                label9.Text = "B";
            else if (per < 60 && per >= 50)
                label9.Text = "C";
            else if (per < 50 && per >= 40)
                label9.Text = "D";
            else
                label9.Text = "E";

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" && label7.Text != "" && label8.Text != "" && label9.Text != "")
            {
                string sql = "insert into Table2 values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + label7.Text + "','" + label8.Text + "','" + label9.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();

                int a = da.Fill(dt);

                if (a >= 0)
                {
                    MessageBox.Show("Sucssesfully Saved !", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clear();
                }
                else
                {
                    MessageBox.Show("Are you Missing something!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    clear();
                }
            }
        }
    }

}

