﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace stud_info_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" && comboBox1.Text != "")
            {
                string sql = "insert into Table1 values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + comboBox1.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();

                int a = da.Fill(dt);

                if (a >= 0)
                {
                    MessageBox.Show("Data Inserted!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clear();
                }
                else
                {
                    MessageBox.Show("Something Missing!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    clear();
                }
            }

            else
            {
                MessageBox.Show("Plese enter values Properly!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }


        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            comboBox1.SelectedIndex = -1;
            textBox1.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f3 = new Form2();
            f3.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string connectionstring = @"Data Source=.\SQLEXPRESS;AttachDbFilename="C:\Users\Viral\Desktop\stud info 1\stud info 1\bin\Debug\Database1.mdf";Integrated Security=True;User Instance=True";
            SqlConnection cn = new SqlConnection(connectionstring);
            cn.Open();
            string Id = textBox1.Text;
            string Name = textBox2.Text;
            string Address = textBox3.Text;
            string Cls = textBox4.Text;
            string Stream = textBox5.Text;
            string Sem = textBox6.Text;
            string City = comboBox1.Text;
            string sql = "update Table1 set Name = '" + textBox2.Text + "',Address='" + textBox3.Text + "',Cls='" + textBox4.Text + "',Stream='" + textBox5.Text + "',Sem='" + textBox6.Text + "',City='" + comboBox1.Text + "' where name='" + textBox2.Text + "',Address='" + textBox3.Text + "',Cls='" + textBox4.Text + "',Stream='" + textBox5.Text + "',Sem='" + textBox6.Text + "',City='" + comboBox1.Text + "'";
            SqlCommand cd = new SqlCommand(sql,cn);
            cn.Close();
            MessageBox.Show("It's Updated !");
            clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
              string connectionstring = @"Data Source=.\SQLEXPRESS;AttachDbFilename="C:\Users\Viral\Desktop\stud info 1\stud info 1\bin\Debug\Database1.mdf";Integrated Security=True;User Instance=True";
              SqlConnection cn = new SqlConnection(connectionstring);
            cn.Open();
            string Id = textBox1.Text;

            string sql = "delele from Table1 where Id = " + Id;
            SqlCommand cd = new SqlCommand(sql, cn);
            cn.Close();
            MessageBox.Show("Deleted Successfully !");
            clear();
        }
    }
}
