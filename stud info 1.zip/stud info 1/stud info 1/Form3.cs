﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace stud_info_1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionstring = @"Data Source=.\SQLEXPRESS;AttachDbFilename="C:\Users\Viral\Desktop\stud info 1\stud info 1\bin\Debug\Database1.mdf";Integrated Security=True;User Instance=True";
            SqlConnection cn = new SqlConnection(connectionstring);
            cn.Open();
            string sql = "select * from Table1";
            SqlCommand cd = new SqlCommand(sql, cn);
            var read = cd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(read);
            dataGridView1.DataSource = dt;
            cn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
             Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        
    }
}
